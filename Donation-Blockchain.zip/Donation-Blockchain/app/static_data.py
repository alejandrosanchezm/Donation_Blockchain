agenda = []

ip_cliente = None
puerto_cliente = None
ip_coordinador = None
puerto_coordinador = None

num_personas = 0

tabla = []

blockchain = None

adminPassword = ["123456","abc"]
intentos = 2
register = False

id_login = ""